<?php
class AEM_Admin {
    public function __construct() {
        add_filter('manage_event_posts_columns', [$this, 'columns']);
        add_action('manage_event_posts_custom_column', [$this, 'column_content'], 10, 2);
    }
    
    public function columns($columns) {
        $new = [];
        foreach ($columns as $key => $val) {
            $new[$key] = $val;
            if ($key === 'title') {
                $new['event_date'] = 'Date';
                $new['location'] = 'Location';
            }
        }
        return $new;
    }
    
    public function column_content($column, $post_id) {
        if ($column === 'event_date') {
            echo get_post_meta($post_id, '_aem_date', true) ?: '—';
        }
        if ($column === 'location') {
            echo get_post_meta($post_id, '_aem_location', true) ?: '—';
        }
    }
}