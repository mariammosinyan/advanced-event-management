<?php
class AEM_REST_Controller {
    public function register_routes() {
        register_rest_route('aem/v1', '/events', [
            'methods' => 'GET',
            'callback' => [$this, 'get_events'],
            'permission_callback' => '__return_true',
        ]);
    }
    
    public function get_events($request) {
        $query = new WP_Query([
            'post_type' => 'event',
            'posts_per_page' => 10,
        ]);
        
        $events = [];
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $events[] = [
                    'id' => get_the_ID(),
                    'title' => get_the_title(),
                    'date' => get_post_meta(get_the_ID(), '_aem_date', true),
                    'permalink' => get_permalink(),
                ];
            }
            wp_reset_postdata();
        }
        
        return rest_ensure_response(['success' => true, 'data' => $events]);
    }
}