<?php
class AEM_Post_Types {
    public function register_event_cpt() {
        register_post_type('event', [
            'labels' => [
                'name' => 'Events',
                'singular_name' => 'Event',
            ],
            'public' => true,
            'has_archive' => true,
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-calendar-alt',
            'supports' => ['title', 'editor', 'thumbnail'],
            'rewrite' => ['slug' => 'events'],
        ]);
    }
}