<?php
class AEM_Taxonomies {
    public function register_taxonomies() {
        register_taxonomy('event_category', ['event'], [
            'labels' => ['name' => 'Categories'],
            'hierarchical' => true,
            'show_in_rest' => true,
        ]);
    }
}