<?php
class AEM_Activator {
    public static function activate() {
        require_once AEM_PLUGIN_DIR . 'includes/class-aem-post-types.php';
        $post_types = new AEM_Post_Types();
        $post_types->register_event_cpt();
        flush_rewrite_rules();
    }
}