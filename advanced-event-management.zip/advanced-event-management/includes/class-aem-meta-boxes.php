<?php
class AEM_Meta_Boxes {
    public function add_meta_boxes() {
        add_meta_box('aem_details', 'Event Details', 
            [$this, 'render'], 'event', 'normal', 'high');
    }
    
    public function render($post) {
        wp_nonce_field('aem_save', 'aem_nonce');
        $date = get_post_meta($post->ID, '_aem_date', true);
        $location = get_post_meta($post->ID, '_aem_location', true);
        ?>
        <p><label>Date:</label><br>
        <input type="datetime-local" name="aem_date" value="<?php echo esc_attr($date); ?>" style="width:100%"></p>
        <p><label>Location:</label><br>
        <input type="text" name="aem_location" value="<?php echo esc_attr($location); ?>" style="width:100%"></p>
        <?php
    }
    
    public function save_meta($post_id, $post) {
        if (!isset($_POST['aem_nonce']) || !wp_verify_nonce($_POST['aem_nonce'], 'aem_save')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        
        if (isset($_POST['aem_date'])) {
            update_post_meta($post_id, '_aem_date', sanitize_text_field($_POST['aem_date']));
        }
        if (isset($_POST['aem_location'])) {
            update_post_meta($post_id, '_aem_location', sanitize_text_field($_POST['aem_location']));
        }
    }
}