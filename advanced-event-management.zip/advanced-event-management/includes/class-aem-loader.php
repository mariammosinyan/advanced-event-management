<?php
class AEM_Loader {
    protected $actions = [];
    
    public function __construct() {
        $this->load_dependencies();
        $this->define_hooks();
    }
    
    private function load_dependencies() {
        require_once AEM_PLUGIN_DIR . 'includes/class-aem-post-types.php';
        require_once AEM_PLUGIN_DIR . 'includes/class-aem-taxonomies.php';
        require_once AEM_PLUGIN_DIR . 'includes/class-aem-meta-boxes.php';
        require_once AEM_PLUGIN_DIR . 'admin/class-aem-admin.php';
        require_once AEM_PLUGIN_DIR . 'public/class-aem-shortcodes.php';
        require_once AEM_PLUGIN_DIR . 'api/class-aem-rest-controller.php';
    }
    
    private function define_hooks() {
        $post_types = new AEM_Post_Types();
        $taxonomies = new AEM_Taxonomies();
        $meta_boxes = new AEM_Meta_Boxes();
        $rest = new AEM_REST_Controller();
        $shortcodes = new AEM_Shortcodes();
        
        add_action('init', [$post_types, 'register_event_cpt']);
        add_action('init', [$taxonomies, 'register_taxonomies']);
        add_action('add_meta_boxes', [$meta_boxes, 'add_meta_boxes']);
        add_action('save_post_event', [$meta_boxes, 'save_meta'], 10, 2);
        add_action('rest_api_init', [$rest, 'register_routes']);
        
        add_shortcode('events_list', [$shortcodes, 'events_list']);
    }
    
    public function run() {
        // Everything loaded
    }
}