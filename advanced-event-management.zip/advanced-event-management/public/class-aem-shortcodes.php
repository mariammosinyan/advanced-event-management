<?php
class AEM_Shortcodes {
    public function events_list($atts) {
        $atts = shortcode_atts(['limit' => 10], $atts);
        
        $query = new WP_Query([
            'post_type' => 'event',
            'posts_per_page' => intval($atts['limit']),
        ]);
        
        ob_start();
        if ($query->have_posts()) {
            echo '<div class="events-list">';
            while ($query->have_posts()) {
                $query->the_post();
                ?>
                <div class="event-item">
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo get_post_meta(get_the_ID(), '_aem_date', true); ?></p>
                    <p><?php the_excerpt(); ?></p>
                </div>
                <?php
            }
            echo '</div>';
            wp_reset_postdata();
        }
        return ob_get_clean();
    }
}