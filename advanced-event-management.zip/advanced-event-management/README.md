# Advanced Event Management Plugin

WordPress plugin for event management.

## Features
- Custom Post Types
- REST API
- Shortcodes
- Admin Interface

## Installation
1. Upload to plugins folder
2. Activate in WordPress
3. Use Events menu